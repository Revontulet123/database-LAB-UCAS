||--ticket_html
||----css 					网站样式文件
||----fonts 				网站字体文件
||----image 				网站图片
||----js					网站js代码
||----admin.php				管理员界面
||----booking_new.php		订票界面
||----cancel.php			取消订单界面
||----detail.php			订单详情
||----index.php				网站主页 **
||----login.php				登录页面
||----logincheck.php		检查能否成功登录
||----myorder.php			查询订单页面	
||----myorder_result.php	查询结果页面
||----orderpage.php			管理员状态下查看订单
||----req4_new.php			需求4,按车次查列车
||----req5_new.php			需求5,按城市查列车
||----req5_new.php			需求5 换乘页面
||----signup.php			注册页面
||----signupcheck.php		检查是否符合注册条件
||----success.php			成功购票页面